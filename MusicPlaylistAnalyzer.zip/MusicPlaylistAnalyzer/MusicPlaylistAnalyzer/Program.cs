﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;

namespace ConsoleApp1
{
    class Program
    {
        static void constructOutput(List<string[]> list, StreamWriter file)
        {
            for (int i = 0; i < list.Count; i++)
            {
                file.WriteLine("Name: " + list[i][0] + ", Artist: " + list[i][1] + ", Album: " + list[i][2] + ", Genre: " +
                    "" + list[i][3] + ", Size: " + list[i][4] + ", Time: " + list[i][5] + ", Year: " + list[i][6] + ", Plays: " + list[i][7]);
            }
        }

        static void constructNameOutput(List<string[]> list, StreamWriter file)
        {
            for (int i = 0; i < list.Count; i++)
            {
                file.WriteLine(list[i][0] + "\n");
            }
        }

        static void Main(string[] args)
        {
            if (args.Length != 2)
            {
                Console.WriteLine("Wrong command line arguments, please provide two valid file names.");
                return;
            }

            Console.WriteLine("Reading file");
            string[] lines;
            try
            {
                lines = File.ReadAllLines(args[0]);
            }
            catch (FileNotFoundException)
            {
                Console.WriteLine("Could not find the file: " + args[0]);
                return;
            }

            string[][] splitData = new string[lines.Length - 1][];
            for (int i = 1; i < lines.Length; i++)
            {
                splitData[i - 1] = lines[i].Split('\t');
            }
            var playsOver200 = new List<string[]>();
            var alternative = new List<string[]>();
            var hiphop = new List<string[]>();
            var fishbowl = new List<string[]>();
            var before1970 = new List<string[]>();
            var longSongName = new List<string[]>();
            var longestSong = new List<string[]>();
            long maxTime = -1;
            Console.WriteLine("Starting data analysis");
            for (int i = 0; i < splitData.Length; i++)
            {
                if (splitData[i].Length != 8)
                {
                    Console.WriteLine("Invalid number of data entries found on line " + (i + 1) + ", skipping this data");
                    continue;
                }
                try
                {
                    if (System.Convert.ToInt64(splitData[i][7]) >= 200)
                    {
                        playsOver200.Add(splitData[i]);
                    }
                }
                catch (FormatException)
                {
                    Console.WriteLine("Invalid integer format found in input file at line: " + i);
                    return;
                }
                if (splitData[i][3].Equals("Alternative"))
                {
                    alternative.Add(splitData[i]);
                }
                if (splitData[i][3].Equals("Hip-Hop/Rap"))
                {
                    hiphop.Add(splitData[i]);
                }
                if (splitData[i][2].Equals("Welcome to the Fishbowl"))
                {
                    fishbowl.Add(splitData[i]);
                }
                try
                {
                    if (System.Convert.ToInt64(splitData[i][6]) < 1970)
                    {
                        before1970.Add(splitData[i]);
                    }
                }
                catch (FormatException)
                {
                    Console.WriteLine("Invalid integer format found in input file at line: " + i);
                    return;
                }
                if (splitData[i][0].Length > 85)
                {
                    longSongName.Add(splitData[i]);
                }
                try
                {
                    if (System.Convert.ToInt64(splitData[i][5]) > maxTime)
                    {
                        longestSong.Add(splitData[i]);
                        maxTime = System.Convert.ToInt64(splitData[i][5]);
                    }
                }
                catch (FormatException)
                {
                    Console.WriteLine("Invalid integer format found in input file at line: " + i);
                    return;
                }
            }

            Console.WriteLine("Writing file");
            StreamWriter file = new StreamWriter(args[1], true);
            file.WriteLine("Music Playlist Report");
            file.WriteLine("Songs that received 200 or more plays:");
            constructOutput(playsOver200, file);
            file.WriteLine("\nNumber of Alternative songs: " + alternative.Count);
            file.WriteLine("\nNumber of Hip-Hop/Rap songs: " + hiphop.Count);
            file.WriteLine("\nSongs from the album Welcome to the Fishbowl:");
            constructOutput(fishbowl, file);
            file.WriteLine("\nSongs from before 1970:");
            constructOutput(before1970, file);
            file.WriteLine("\nSong names longer than 85 characters:");
            constructNameOutput(longSongName, file);
            file.WriteLine("Longest song: ");
            var longestFinal = new List<string[]>();
            longestFinal.Add(longestSong[longestSong.Count - 1]);
            constructOutput(longestFinal, file);
            file.Flush();
            file.Close();
            Console.WriteLine("Finished writing");
        }
    }
}
